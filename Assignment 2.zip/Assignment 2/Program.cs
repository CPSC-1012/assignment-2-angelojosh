﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

using System;

namespace RoadTripCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\nWelcome to the Road Trip Calculator\n");

            const double YOUR_CAR_EFFICIENCY = 11.9;
            const double FRIEND_CAR_EFFICIENCY = 8.7;

            Random rand = new Random();
            double gasPrice = Math.Round(rand.NextDouble() * (2.00 - 1.40) + 1.40, 2);

            bool continueProgram = true;

            while (continueProgram)
            {
                int distance;
                Console.Write("Please enter the trip distance in whole kilometers: ");
                while (true)
                {

                    string distanceInput = Console.ReadLine();

                    if (int.TryParse(distanceInput, out distance) && distance > 0)
                        break;
                    else
                        Console.Write("Invalid number. Please enter distance in whole kilometers: ");
                }

                int vehicleChoice;
                double efficiency = 0;
                while (true)
                {
                    Console.Write("Will you be taking [y]our vehicle or your [f]riend's?  ");
                    string input = Console.ReadLine().ToUpper();

                    if (input.Length != 1)
                    {
                        Console.WriteLine("Please enter one character only");
                        continue;
                    }

                    vehicleChoice = input[0];

                    if (vehicleChoice == 'Y' || vehicleChoice == 'F')
                    {
                        efficiency = (vehicleChoice == 'Y') ? YOUR_CAR_EFFICIENCY : FRIEND_CAR_EFFICIENCY;
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Invalid Character please try again");
                    }
                }

                double fuelUsed = (distance / 100.0) * efficiency;

                double fuelCost = fuelUsed * gasPrice;
                fuelCost = Math.Round(fuelCost, 2);

                double snackCost;
                if (distance < 200)
                    snackCost = 30;
                else if (distance < 500)
                    snackCost = 50;
                else if (distance < 1000)
                    snackCost = 80;
                else
                    snackCost = 120;

                double totalCost = fuelCost + snackCost;

                
                Console.WriteLine($"\n\nTrip length: {distance} km");
                Console.WriteLine($"Fuel efficiency: {efficiency} L per 100 km");
                Console.WriteLine($"Fuel needed: {fuelUsed:F2} L");
                Console.WriteLine($"Fuel Price: ${gasPrice:F2} per L");        

                Console.WriteLine($"\nFuel Cost: ${fuelCost:F2}");
                Console.WriteLine($"Snack Cost: ${snackCost:F2}");
                Console.WriteLine("-------------------");
                Console.WriteLine($"Total Trip Cost: ${totalCost:F2}");

                Console.Write("\nWould you like to do another calculation?\nEnter Y to continue or any other key to Exit: ");
                string repeat = Console.ReadLine().ToUpper();
                if (repeat != "Y")
                    continueProgram = false;
            }
        }
    }
}



